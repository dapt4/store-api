package com.all.storeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
